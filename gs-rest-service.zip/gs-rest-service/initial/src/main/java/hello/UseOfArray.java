package hello;

public class UseOfArray {

     
    private final String myarray[];

    public UseOfArray(String [] myarray ) {
         this.myarray = myarray ; 
    }

    public String [] getArray() {
        return myarray;
    }

     
}